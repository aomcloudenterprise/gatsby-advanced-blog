---
title: Blog
template: blog.hbt
---
    <ul>
        {{#each collections.articles}}
            <li>
                <h3>{{this.title}}</h3>
                <article>{{this.contents}}</article>
            </li>
        {{/each}}
    </ul>
</article>

{{> footer}}




