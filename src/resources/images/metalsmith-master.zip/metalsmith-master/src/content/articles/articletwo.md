---
title: "This metalsmith demo site is live"
date: 2015-12-28
template: article.hbt
permalink: true
---

## Going Live

This metalsmith demo site is now live on netlify.
