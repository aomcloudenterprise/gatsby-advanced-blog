---
title: "The New Years Post"
date: 2015-12-31
template: article.hbt
permalink: true
---

## Happy New Year

Happy New Year and may 2016 be a prosperous one with static site generators taking over the internet.
