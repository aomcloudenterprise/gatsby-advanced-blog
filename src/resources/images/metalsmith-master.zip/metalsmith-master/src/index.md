---
title: Home
template: home.hbt
permalink: false
---

## Welcome to Metalsmith

This is a basic Metalsmith Demonstration Site, linked to GitHub and hosted on Netlify with continous deployment.